module.exports = member => {
    let username = member.user.username;
    member.sendMessage('Selamlar,De�erli ' + username + ' Discord Sunucumaza Ho�geldin  ,  Keyifli Vakit Ge�irmen Dile�iyle. ||https://discord.gg/B5P2MCM|| Buda sunucumuzun s�n�rs�z linki   ');

};